<?php
	include "../koneksi.php";
	include "../session.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css1/sb-admin-2.min.css" rel="stylesheet" />
	<link href="../css1/sb-admin-2.css" rel="stylesheet" />
	<script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
	</script>
	<link rel="stylesheet" href="../fontawesome/fontawesome/css/all.css" />
    <title>Data Berobat</title>
</head>
<body>
	<div id="wrapper">
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon ">
                    <i class="fas fa-fw fa-user"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Administrator</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
			<li class="nav-item">
                <a class="nav-link" href="../index.php">
                    <i class="fas fa-house"></i>
                    <span>Dashboard</span></a>
            <li class="nav-item">
                <a class="nav-link" href="../data.php">
                    <i class="fas fa-clipboard"></i>
                    <span>Data</span></a>
            </li>
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Page Heading -->
    
			<div class="container shadow p-3">
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb bg-warning">
					<li class="breadcrumb-item active text-white" aria-current="page">
						<i class="fa-solid fa-syringe fa-2x"></i> 
						Tabel Berobat
					</li>
				  </ol>
				</nav>
				<hr>
				<div class="btn-toolbar mb-2 mb-md-10">
					<a class="btn btn-secondary me-3" href="../data.php" role="button"><i class="fa-solid fa-angles-left me-1"></i>Kembali</a>
					<a class="btn btn-success" href="berobat_tambah.php" role="button"><i class="fa-solid fa-plus me-1"></i>Tambah</a>
				</div>
				<div class="card">
					<div class="table-responsive">
						<table class="table table-striped table-hover">
							<thead>
								<tr>
									<td>No</td>
									<td>Id Berobat</td>
									<td>Nama Pasien</td>
									<td>Nama Dokter</td>
									<td>Tanggal Berobat</td>
									<td>Keluhan Pasien</td>
									<td>Hasil Diagnosa</td>
									<td>Penatalaksanaan</td> 
									<td>Aksi</td>
								</tr>
							</thead>
							<?php
							$no = 1;
							$query = mysqli_query($con, 'SELECT * FROM berobat2');
							while ($data = mysqli_fetch_array($query)) {
							?>
								<tr>
									<td><?php echo $no++ ?></td>
									<td><?php echo $data['id_berobat'] ?></td>
									<td><?php echo $data['nama_pasien'] ?></td>
									<td><?php echo $data['nama_dokter'] ?></td>
									<td><?php echo $data['tgl_berobat'] ?></td>
									<td><?php echo $data['keluhan_pasien'] ?></td>
									<td><?php echo $data['hasil_diagnosa'] ?></td>
									<td><?php echo $data['penatalaksanaan'] ?></td>
									<td>
										<a class="btn btn-success" href="berobat_ubah.php?id=<?= $data['id_berobat'];?>" role="button"><i class="fa-solid fa-pen-to-square"></i></a>
										<a class="btn btn-danger" href="berobat_hapus.php?id=<?= $data['id_berobat'];?>" role="button"><i class="fa-solid fa-trash-can"></i></a>
									</td>
								</tr>
							<?php } ?>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php require "../footer.php";?>

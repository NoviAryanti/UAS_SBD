<?php
$host="localhost";
$user="adminklinik";
$password="312010156";
$db="klinik_312010156";

$con = mysqli_connect($host,$user,$password,$db);
if (!$con){
	  die("Koneksi gagal:".mysqli_connect_error());
}
?>
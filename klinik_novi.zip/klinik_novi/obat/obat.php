<?php
	include "../koneksi.php";
	include "../session.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css1/sb-admin-2.min.css" rel="stylesheet" />
	<link href="../css1/sb-admin-2.css" rel="stylesheet" />
	<script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
	</script>
	<link rel="stylesheet" href="../fontawesome/fontawesome/css/all.css" />
    <title>Data Obat</title>
</head>
<body>
	<div id="wrapper">
      <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon ">
                    <i class="fas fa-fw fa-user"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Administrator</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
			<li class="nav-item">
                <a class="nav-link" href="../index.php">
                    <i class="fas fa-house"></i>
                    <span>Dashboard</span></a>
            <li class="nav-item">
                <a class="nav-link" href="../data.php">
                    <i class="fas fa-clipboard"></i>
                    <span>Data</span></a>
            </li>
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
			<div class="container shadow p-3">
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb bg-warning">
					<li class="breadcrumb-item active text-white" aria-current="page">
						<i class="fa-solid fa-capsules fa-2x"></i> 
						Tabel Obat
					</li>
				  </ol>
				</nav>
				<hr>
				<div class="btn-toolbar mb-2 mb-md-10">
					<a class="btn btn-secondary me-3" href="../data.php" role="button"><i class="fa-solid fa-angles-left me-1"></i>Kembali</a>
					<a class="btn btn-success" href="obat_tambah.php" role="button"><i class="fa-solid fa-plus me-1"></i>Tambah</a>
				</div>
				<div class="card mb-5">
					<div class="table-responsive">
						<table class="table table-striped table-hover">
							<thead>
								<tr>
									<td>No</td>
									<td>Id Obat</td>
									<td>Nama Obat</td>
									<td>Aksi</td>
								</tr>
							</thead>
							<?php
							$no = 1;
							$sql = mysqli_query($con, 'SELECT * FROM obat');
							while ($data = mysqli_fetch_array($sql)) {
							?>
								<tr>
									<td><?php echo $no++ ?></td>
									<td><?php echo $data['id_obat'] ?></td>
									<td><?php echo $data['nama_obat'] ?></td>
									<td>
										<a class="btn btn-success" href="obat_ubah.php?id=<?= $data['id_obat'];?>" role="button"><i class="fa-solid fa-pen-to-square"></i></a>
										<a class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus data..?');" href="obat_hapus.php?id=<?= $data['id_obat'];?>" role="button"><i class="fa-solid fa-trash-can"></i></a>
									</td>
								</tr>
							<?php } ?>
						</table>
					</div>
				</div>
				<hr class="divider">
				<div class="card mt-5">
					<div class="card-header">
						<h4>Trigger</h4>
					</div>
					<div class="table-responsive">
						<table class="table table-striped table-hover">
							<thead class="card-header text-white bg-secondary">
								<tr>
									<td>No</td>
									<td>Id Log</td>
									<td>Id Obat</td>
									<td>Obat Lama</td>
									<td>Obat Baru</td>
									<td>Waktu</td>
									<td>Aksi</td>
								</tr>
							</thead>
							<?php
							$no = 1;
							$sql = mysqli_query($con, 'SELECT * FROM log_obat');
							while ($data = mysqli_fetch_array($sql)) {
							?>
								<tr>
									<td><?php echo $no++ ?></td>
									<td><?php echo $data['id_log'] ?></td>
									<td><?php echo $data['id_obat'] ?></td>
									<td><?php echo $data['obat_lama'] ?></td>
									<td><?php echo $data['obat_baru'] ?></td>
									<td><?php echo $data['waktu'] ?></td>
									<td><a class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus data..?');" href="hapus_triger.php?id=<?= $data['id_log'];?>" role="button"><i class="fa-solid fa-trash-can"></i></a></td>
								</tr>
							<?php } ?>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php require "../footer.php";?>